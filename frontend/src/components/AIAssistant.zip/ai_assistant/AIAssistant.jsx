import { useState, useRef, useEffect } from 'react'

// ─── Airline + flight data for AI context ────────────────
const AIRLINE_INFO = {
  'AI':'Air India','6E':'IndiGo','EK':'Emirates','QR':'Qatar Airways',
  'BA':'British Airways','AA':'American Airlines','UA':'United Airlines',
  'LH':'Lufthansa','AF':'Air France','KL':'KLM','SQ':'Singapore Airlines',
  'CX':'Cathay Pacific','NH':'All Nippon Airways','KE':'Korean Air',
  'QF':'Qantas','SG':'SpiceJet','TK':'Turkish Airlines','EY':'Etihad',
  'VS':'Virgin Atlantic','MH':'Malaysia Airlines','IX':'Air India Express',
}

// Quick action suggestions
const QUICK_ACTIONS = [
  { icon:'🔍', label:'Analyze my flight',  prompt:'Analyze the current flight and tell me everything important about it' },
  { icon:'🧠', label:'Will it be delayed?', prompt:'Based on the flight data, predict if this flight will be delayed and why' },
  { icon:'💺', label:'Best seat advice',    prompt:'Which seat should I pick on this flight and why?' },
  { icon:'🌤', label:'Weather impact',      prompt:'How will the weather at both airports affect this flight?' },
  { icon:'📝', label:'Trip summary',        prompt:'Generate a complete trip summary and travel tips for this flight' },
  { icon:'💰', label:'Price insights',      prompt:'Is the current price good? When is the best time to book this route?' },
  { icon:'🏛', label:'Terminal tips',       prompt:'Give me tips for the departure terminal and gate for this flight' },
  { icon:'❓', label:'What to do if delayed',prompt:'My flight is delayed. What should I do right now?' },
]

export default function AIAssistant({ currentFlight, origin, destination, eta }) {
  const [open, setOpen]         = useState(false)
  const [messages, setMessages] = useState([])
  const [input, setInput]       = useState('')
  const [loading, setLoading]   = useState(false)
  const [mode, setMode]         = useState('chat') // chat | suggestions
  const bottomRef               = useRef(null)
  const inputRef                = useRef(null)

  // Welcome message when flight is loaded
  useEffect(() => {
    if (currentFlight && open && messages.length === 0) {
      const airline = AIRLINE_INFO[currentFlight.airline_code] || currentFlight.airline
      setMessages([{
        role: 'assistant',
        content: `✈ Hi! I'm your FlightSight AI Assistant.\n\nI can see you're tracking **${currentFlight.flight_number}** (${airline}) from **${currentFlight.origin} → ${currentFlight.destination}**.\n\nCurrent status: **${currentFlight.status}**${currentFlight.delay_minutes > 0 ? ` (+${currentFlight.delay_minutes} min delay)` : ''}\n\nI can help you with:\n• Delay predictions & analysis\n• Seat recommendations\n• Weather impact on your flight\n• Trip summaries & travel tips\n• Price insights\n• Terminal & gate advice\n\nWhat would you like to know?`,
        timestamp: new Date(),
      }])
    } else if (!currentFlight && open && messages.length === 0) {
      setMessages([{
        role: 'assistant',
        content: `✈ Hi! I'm your **FlightSight AI Assistant**.\n\nSearch for a flight first and I'll give you:\n• Real-time delay predictions\n• Smart seat recommendations\n• Weather impact analysis\n• Complete trip summaries\n• Price insights & tips\n\nOr ask me anything about aviation, airports, or travel! 🌍`,
        timestamp: new Date(),
      }])
    }
  }, [open, currentFlight])

  // Auto scroll to bottom
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, loading])

  // Focus input when opened
  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 100)
  }, [open])

  const buildSystemPrompt = () => {
    let system = `You are FlightSight AI, an expert aviation assistant built into the FlightSight flight tracking dashboard. You are helpful, concise, and knowledgeable about aviation, airports, airlines, travel tips, and flight operations.

Your capabilities:
1. DELAY PREDICTION: Analyze flight data and predict delays with reasoning
2. SEAT RECOMMENDATIONS: Give specific seat advice based on aircraft type, route, and preferences  
3. TRIP SUMMARIES: Generate complete travel briefs with tips, packing lists, cultural info
4. PRICE INSIGHTS: Explain fare trends and booking strategies
5. WEATHER IMPACT: Explain how weather affects flights
6. TERMINAL TIPS: Provide airport navigation and lounge advice
7. GENERAL AVIATION: Answer any aviation-related question

Always be specific, actionable, and friendly. Use emojis sparingly. Format with markdown when helpful.`

    if (currentFlight) {
      system += `\n\nCURRENT FLIGHT DATA:
- Flight: ${currentFlight.flight_number}
- Airline: ${currentFlight.airline} (${currentFlight.airline_code})
- Route: ${currentFlight.origin} → ${currentFlight.destination}
- Aircraft: ${currentFlight.aircraft_type || 'Unknown'}
- Status: ${currentFlight.status}
- Departure: ${currentFlight.departure_time}
- Arrival: ${currentFlight.arrival_time}
- Duration: ${currentFlight.flight_duration || 'Unknown'}
- Delay: ${currentFlight.delay_minutes > 0 ? `+${currentFlight.delay_minutes} minutes` : 'None'}
- Delay Cause: ${currentFlight.delay_cause || 'None'}
- Delay Confidence: ${currentFlight.delay_confidence ? `${Math.round(currentFlight.delay_confidence * 100)}%` : 'N/A'}
- Terminal: ${currentFlight.terminal || 'TBD'}
- Gate: ${currentFlight.gate || 'TBD'}
- Boarding Status: ${currentFlight.boarding_status || 'Unknown'}
- Altitude: ${currentFlight.altitude ? `${currentFlight.altitude.toLocaleString()} ft` : 'Ground'}
- Speed: ${currentFlight.speed ? `${currentFlight.speed} kts (${Math.round(currentFlight.speed * 1.852)} km/h)` : 'Stationary'}
- Position: ${currentFlight.latitude && currentFlight.longitude ? `${currentFlight.latitude.toFixed(2)}°, ${currentFlight.longitude.toFixed(2)}°` : 'Unknown'}`
    }

    if (origin) {
      system += `\n\nDEPARTURE AIRPORT:
- Code: ${origin.code}
- Name: ${origin.name}
- City: ${origin.city}, ${origin.country}
- Traffic: ${origin.traffic_level}
- Weather: ${origin.weather}`
    }

    if (destination) {
      system += `\n\nARRIVAL AIRPORT:
- Code: ${destination.code}
- Name: ${destination.name}
- City: ${destination.city}, ${destination.country}
- Traffic: ${destination.traffic_level}
- Weather: ${destination.weather}`
    }

    if (eta && eta.remainingKm) {
      system += `\n\nETA DATA:
- Remaining Distance: ${eta.remainingKm.toLocaleString()} km
- ETA: ${eta.etaTime}
- Time Remaining: ${Math.floor(eta.etaMinutes / 60)}h ${eta.etaMinutes % 60}m`
    }

    return system
  }

  const sendMessage = async (userMessage) => {
    if (!userMessage.trim() || loading) return
    setMode('chat')

    const userMsg = { role: 'user', content: userMessage, timestamp: new Date() }
    const newMessages = [...messages, userMsg]
    setMessages(newMessages)
    setInput('')
    setLoading(true)

    try {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          system: buildSystemPrompt(),
          messages: newMessages
            .filter(m => m.role === 'user' || m.role === 'assistant')
            .map(m => ({ role: m.role, content: m.content })),
        }),
      })

      const data = await response.json()
      const text = data.content?.[0]?.text || 'Sorry, I could not generate a response.'

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: text,
        timestamp: new Date(),
      }])
    } catch (err) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: '⚠️ Connection error. Please check your API key and try again.',
        timestamp: new Date(),
        error: true,
      }])
    } finally {
      setLoading(false)
    }
  }

  const handleQuickAction = (prompt) => {
    sendMessage(prompt)
  }

  const clearChat = () => {
    setMessages([])
    setTimeout(() => {
      if (currentFlight && open) {
        const airline = AIRLINE_INFO[currentFlight.airline_code] || currentFlight.airline
        setMessages([{
          role: 'assistant',
          content: `Chat cleared! I'm still tracking **${currentFlight.flight_number}** (${airline}). How can I help?`,
          timestamp: new Date(),
        }])
      }
    }, 100)
  }

  // Format message content (simple markdown)
  const formatContent = (text) => {
    return text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/`(.*?)`/g, '<code style="background:rgba(0,212,255,.1);padding:1px 5px;border-radius:3px;font-family:monospace;font-size:12px">$1</code>')
      .replace(/\n/g, '<br/>')
      .replace(/•/g, '•')
  }

  return (
    <>
      {/* ── Floating button ── */}
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          position: 'fixed', bottom: 24, right: 24, zIndex: 1000,
          width: 56, height: 56, borderRadius: '50%', cursor: 'pointer',
          border: 'none',
          background: open
            ? 'linear-gradient(135deg,#FF3860,#CC0040)'
            : 'linear-gradient(135deg,#9B6BFF,#6B3FCC)',
          boxShadow: open
            ? '0 4px 20px rgba(255,56,96,.5)'
            : '0 4px 20px rgba(155,107,255,.5)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 22, transition: 'all .3s',
          animation: !open ? 'glowPulse 3s ease-in-out infinite' : 'none',
        }}
        title="FlightSight AI Assistant"
      >
        {open ? '✕' : '🤖'}
      </button>

      {/* Notification dot when flight is loaded */}
      {!open && currentFlight && (
        <div style={{
          position: 'fixed', bottom: 72, right: 24, zIndex: 1001,
          background: '#00FF88', borderRadius: '50%', width: 10, height: 10,
          boxShadow: '0 0 8px #00FF88', animation: 'pulse 2s infinite',
        }}/>
      )}

      {/* ── Chat panel ── */}
      {open && (
        <div style={{
          position: 'fixed', bottom: 92, right: 24, zIndex: 999,
          width: 380, height: 580,
          background: 'var(--card, #060E1C)',
          border: '1px solid rgba(155,107,255,.4)',
          borderRadius: 16, overflow: 'hidden',
          display: 'flex', flexDirection: 'column',
          boxShadow: '0 20px 60px rgba(0,0,0,.8), 0 0 0 1px rgba(155,107,255,.2)',
          animation: 'fadeUp .25s ease',
        }}>
          {/* Header */}
          <div style={{
            padding: '14px 16px',
            background: 'linear-gradient(135deg,rgba(155,107,255,.2),rgba(155,107,255,.05))',
            borderBottom: '1px solid rgba(155,107,255,.25)',
            display: 'flex', alignItems: 'center', gap: 10,
          }}>
            <div style={{
              width: 36, height: 36, borderRadius: '50%',
              background: 'linear-gradient(135deg,#9B6BFF,#6B3FCC)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 18, flexShrink: 0,
              boxShadow: '0 0 12px rgba(155,107,255,.5)',
            }}>🤖</div>
            <div style={{ flex: 1 }}>
              <div style={{
                fontFamily: 'Orbitron,monospace', fontSize: 11, fontWeight: 700,
                color: '#E4F0FF', letterSpacing: '.1em',
              }}>FLIGHTSIGHT AI</div>
              <div style={{
                fontFamily: 'JetBrains Mono,monospace', fontSize: 9,
                color: '#9B6BFF', display: 'flex', alignItems: 'center', gap: 4,
              }}>
                <span style={{
                  width: 5, height: 5, borderRadius: '50%', background: '#00FF88',
                  display: 'inline-block', boxShadow: '0 0 5px #00FF88',
                  animation: 'pulse 1.5s infinite',
                }}/>
                {loading ? 'Thinking…' : 'Online · Powered by Claude'}
              </div>
            </div>
            {/* Mode buttons */}
            <div style={{ display: 'flex', gap: 4 }}>
              <button
                onClick={() => setMode(m => m === 'suggestions' ? 'chat' : 'suggestions')}
                title="Quick actions"
                style={{
                  width: 28, height: 28, borderRadius: 6, cursor: 'pointer',
                  background: mode === 'suggestions' ? 'rgba(155,107,255,.3)' : 'rgba(255,255,255,.05)',
                  border: `1px solid ${mode === 'suggestions' ? '#9B6BFF' : 'rgba(255,255,255,.1)'}`,
                  color: '#9B6BFF', fontSize: 12, display: 'flex',
                  alignItems: 'center', justifyContent: 'center',
                }}>⚡</button>
              <button
                onClick={clearChat}
                title="Clear chat"
                style={{
                  width: 28, height: 28, borderRadius: 6, cursor: 'pointer',
                  background: 'rgba(255,255,255,.05)',
                  border: '1px solid rgba(255,255,255,.1)',
                  color: '#4A6080', fontSize: 12, display: 'flex',
                  alignItems: 'center', justifyContent: 'center',
                }}>🗑</button>
            </div>
          </div>

          {/* Flight context badge */}
          {currentFlight && (
            <div style={{
              padding: '6px 14px',
              background: 'rgba(0,212,255,.05)',
              borderBottom: '1px solid rgba(0,212,255,.1)',
              display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <span style={{ fontSize: 12 }}>✈</span>
              <span style={{
                fontFamily: 'Orbitron,monospace', fontSize: 9, color: '#00D4FF',
                letterSpacing: '.08em',
              }}>{currentFlight.flight_number}</span>
              <span style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: 9, color: '#3A5472' }}>
                {currentFlight.origin} → {currentFlight.destination}
              </span>
              <span style={{
                marginLeft: 'auto', fontFamily: 'JetBrains Mono,monospace', fontSize: 8,
                fontWeight: 700, padding: '1px 6px', borderRadius: 8,
                background: currentFlight.status === 'Delayed' ? 'rgba(255,176,32,.15)' : 'rgba(0,255,136,.1)',
                color: currentFlight.status === 'Delayed' ? '#FFB020' : '#00FF88',
              }}>{currentFlight.status}</span>
            </div>
          )}

          {/* Quick actions panel */}
          {mode === 'suggestions' && (
            <div style={{
              padding: '10px 12px',
              background: 'rgba(155,107,255,.04)',
              borderBottom: '1px solid rgba(155,107,255,.15)',
              display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5,
            }}>
              {QUICK_ACTIONS.map(a => (
                <button key={a.label}
                  onClick={() => handleQuickAction(a.prompt)}
                  style={{
                    padding: '7px 8px', borderRadius: 7, cursor: 'pointer',
                    background: 'rgba(155,107,255,.08)',
                    border: '1px solid rgba(155,107,255,.2)',
                    color: '#B8CCE0', fontSize: 11, textAlign: 'left',
                    display: 'flex', alignItems: 'center', gap: 5,
                    fontFamily: 'Space Grotesk,sans-serif', fontWeight: 500,
                    transition: 'all .15s',
                  }}
                  onMouseEnter={e => { e.currentTarget.style.background = 'rgba(155,107,255,.18)'; e.currentTarget.style.color = '#9B6BFF' }}
                  onMouseLeave={e => { e.currentTarget.style.background = 'rgba(155,107,255,.08)'; e.currentTarget.style.color = '#B8CCE0' }}
                >
                  <span style={{ fontSize: 13, flexShrink: 0 }}>{a.icon}</span>
                  <span style={{ lineHeight: 1.3, fontSize: 10 }}>{a.label}</span>
                </button>
              ))}
            </div>
          )}

          {/* Messages */}
          <div style={{
            flex: 1, overflowY: 'auto', padding: '12px 14px',
            display: 'flex', flexDirection: 'column', gap: 10,
          }}>
            {messages.map((msg, i) => (
              <div key={i} style={{
                display: 'flex',
                flexDirection: msg.role === 'user' ? 'row-reverse' : 'row',
                gap: 8, alignItems: 'flex-start',
              }}>
                {/* Avatar */}
                <div style={{
                  width: 26, height: 26, borderRadius: '50%', flexShrink: 0,
                  background: msg.role === 'user'
                    ? 'linear-gradient(135deg,#00D4FF,#0099BB)'
                    : 'linear-gradient(135deg,#9B6BFF,#6B3FCC)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 12,
                }}>
                  {msg.role === 'user' ? '👤' : '🤖'}
                </div>

                {/* Bubble */}
                <div style={{
                  maxWidth: '78%',
                  padding: '9px 12px', borderRadius: msg.role === 'user' ? '12px 4px 12px 12px' : '4px 12px 12px 12px',
                  background: msg.role === 'user'
                    ? 'linear-gradient(135deg,rgba(0,212,255,.15),rgba(0,212,255,.08))'
                    : msg.error ? 'rgba(255,56,96,.1)' : 'rgba(255,255,255,.04)',
                  border: `1px solid ${msg.role === 'user' ? 'rgba(0,212,255,.3)' : msg.error ? 'rgba(255,56,96,.2)' : 'rgba(255,255,255,.08)'}`,
                  fontSize: 12,
                  color: '#DCF0FF',
                  fontFamily: 'Space Grotesk,sans-serif',
                  lineHeight: 1.6,
                }}>
                  <div dangerouslySetInnerHTML={{ __html: formatContent(msg.content) }}/>
                  <div style={{
                    fontFamily: 'JetBrains Mono,monospace', fontSize: 8,
                    color: '#2E4A66', marginTop: 5, textAlign: 'right',
                  }}>
                    {msg.timestamp?.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>
            ))}

            {/* Loading indicator */}
            {loading && (
              <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                <div style={{
                  width: 26, height: 26, borderRadius: '50%',
                  background: 'linear-gradient(135deg,#9B6BFF,#6B3FCC)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12,
                }}>🤖</div>
                <div style={{
                  padding: '10px 14px', borderRadius: '4px 12px 12px 12px',
                  background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.08)',
                  display: 'flex', alignItems: 'center', gap: 4,
                }}>
                  {[0,1,2].map(i => (
                    <div key={i} style={{
                      width: 5, height: 5, borderRadius: '50%', background: '#9B6BFF',
                      animation: `pulse 1s ${i * .2}s ease-in-out infinite`,
                    }}/>
                  ))}
                </div>
              </div>
            )}
            <div ref={bottomRef}/>
          </div>

          {/* Input area */}
          <div style={{
            padding: '10px 12px',
            borderTop: '1px solid rgba(155,107,255,.2)',
            background: 'rgba(155,107,255,.03)',
          }}>
            {/* Suggested prompts when no messages */}
            {messages.length <= 1 && mode === 'chat' && (
              <div style={{ display: 'flex', gap: 5, marginBottom: 8, flexWrap: 'wrap' }}>
                {['Will it be delayed?', 'Best seats?', 'Travel tips'].map(s => (
                  <button key={s} onClick={() => sendMessage(s)} style={{
                    padding: '3px 9px', borderRadius: 10, cursor: 'pointer', fontSize: 10,
                    background: 'rgba(155,107,255,.1)', border: '1px solid rgba(155,107,255,.2)',
                    color: '#9B6BFF', fontFamily: 'Space Grotesk,sans-serif',
                    transition: 'all .15s',
                  }}
                  onMouseEnter={e => e.currentTarget.style.background = 'rgba(155,107,255,.2)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'rgba(155,107,255,.1)'}>
                    {s}
                  </button>
                ))}
              </div>
            )}

            <div style={{ display: 'flex', gap: 8 }}>
              <input
                ref={inputRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendMessage(input)}
                placeholder="Ask anything about this flight…"
                disabled={loading}
                style={{
                  flex: 1, height: 38, padding: '0 12px',
                  background: 'rgba(255,255,255,.05)',
                  border: '1px solid rgba(155,107,255,.25)',
                  borderRadius: 8, color: '#DCF0FF', fontSize: 12,
                  fontFamily: 'Space Grotesk,sans-serif', outline: 'none',
                  transition: 'border-color .2s',
                }}
                onFocus={e => e.target.style.borderColor = '#9B6BFF'}
                onBlur={e => e.target.style.borderColor = 'rgba(155,107,255,.25)'}
              />
              <button
                onClick={() => sendMessage(input)}
                disabled={loading || !input.trim()}
                style={{
                  width: 38, height: 38, borderRadius: 8, cursor: 'pointer',
                  border: 'none',
                  background: loading || !input.trim()
                    ? 'rgba(155,107,255,.2)'
                    : 'linear-gradient(135deg,#9B6BFF,#6B3FCC)',
                  color: loading || !input.trim() ? '#4A6080' : 'white',
                  fontSize: 16, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  transition: 'all .2s',
                  boxShadow: loading || !input.trim() ? 'none' : '0 0 12px rgba(155,107,255,.4)',
                }}
              >
                {loading ? '⏳' : '➤'}
              </button>
            </div>
            <div style={{
              fontFamily: 'JetBrains Mono,monospace', fontSize: 8,
              color: '#2E4A66', marginTop: 5, textAlign: 'center',
            }}>
              Powered by Claude AI · Press Enter to send
            </div>
          </div>
        </div>
      )}
    </>
  )
}
